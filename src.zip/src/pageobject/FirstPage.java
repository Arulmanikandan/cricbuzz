package pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


public class FirstPage {

	WebDriver driver = null;
	Actions builder = null;
	
	@FindBy(how=How.XPATH, using="//a[text()='Live Scores']")
	private static WebElement livescore;
	
	@FindBy(how=How.XPATH, using="//a[text()='Pakistan vs Bangladesh,']")
	private static WebElement cmat;
	
	
		public FirstPage(WebDriver driver) {
			this.driver = driver;
			builder = new Actions(driver);
			PageFactory.initElements(driver, this);
		}
		
		public static void toClick(char flag) {
					switch(flag) {
						case '1': livescore.click(); break;
						case '2': cmat.click(); break;
	
		}
	}

}
