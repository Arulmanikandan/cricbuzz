package utilities;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.common.usermodel.HyperlinkType;
import org.apache.poi.sl.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;





public class ExcelWrite {

	
	XSSFWorkbook wbk =null;
    XSSFSheet sht = null;
	XSSFRow row = null;
	XSSFCell cell = null;
	FileOutputStream out = null;
	XSSFCellStyle style =null;
	XSSFFont font = null;
	XSSFColor clr = null;
	CreationHelper cHplr = null;
	XSSFHyperlink link = null;

	public ExcelWrite() {
		wbk = new XSSFWorkbook();
		}
	
	public void toCreateSheet(String data) {
		sht = wbk.createSheet(data);
	}
	
	public void rowCreation(int i,char c) {
		row = sht.createRow(i);
		if(c=='1')
			row.setHeight((short)600);
	}
	
	public void rowCreation(int i) {
		row = sht.createRow(i);
	}
	
	public void cellCreationAndWrite(int i, String data) {
		cell = row.createCell(i);
		cell.setCellValue(data);
		sht.autoSizeColumn(cell.getColumnIndex());
	}
	
	public int lastRow() {
		return sht.getLastRowNum();
	}
		
	public void cellFormatting(String sW1) {
		char[] sW2 = sW1.toCharArray();
		for(int i=0;i<sW2.length;i++)
			switch(sW2[i]) {
			case 'a': style.setAlignment(HorizontalAlignment.CENTER);; break;
			case 'b': style.setAlignment(HorizontalAlignment.RIGHT); break;
			case 'c': style.setAlignment(HorizontalAlignment.LEFT); break;
			case 'd': style.setFillPattern(FillPatternType.SOLID_FOREGROUND); break;
			case 'e': font.setFontHeightInPoints((short) 9); break;
			case 'f': font.setFontHeightInPoints((short) 10); break;
			case 'g': font.setFontHeightInPoints((short) 11); break;
			case 'h': font.setFontName("Segoe UI"); break;
			case 'i': font.setFontName("Calibri"); break;
			case 'j': font.setBold(true); break;
			case 'k': clr = new XSSFColor(new java.awt.Color(74,74,74)); break;
			case 'l': clr = new XSSFColor(new java.awt.Color(235,235,235)); break;
			case 'm': clr = new XSSFColor(new java.awt.Color(102,102,102)); break;
			case 'n': clr = new XSSFColor(new java.awt.Color(255,255,255)); break;
			case 'o': clr = new XSSFColor(new java.awt.Color(24,102,219)); break;
			case 'p': style.setFillForegroundColor(clr); break;
			case 'q': font.setColor(clr); break;
			case 'r': style.setFont(font); break;
			case 's': cell.setCellStyle(style); break;
			case 't': cell = null; clr = null; style = wbk.createCellStyle(); font = wbk.createFont();break;
			case 'u': font.setBold(false); break;
			case 'v': style.setAlignment(HorizontalAlignment.CENTER);; break;
			case 'w': style.setBorderBottom(BorderStyle.THIN); break;
			case 'x': cHplr = null; link = null; cHplr = wbk.getCreationHelper();
					  link = (XSSFHyperlink)cHplr.createHyperlink(HyperlinkType.URL); break;
			case 'y': style.setWrapText(true); break;
			case 'z': style.setBorderTop(BorderStyle.THIN); break;
			case '1': sht.autoSizeColumn(cell.getColumnIndex()); break;
			case '2': row.setHeightInPoints((2 * sht.getDefaultRowHeightInPoints())); break;
			case '3': font.setItalic(true); break;
			case '4': font.setUnderline(XSSFFont.U_SINGLE); break;
			case '5': font.setFontHeightInPoints((short) 25); break;
			}
	}
	
	public void mergeCells(int rFrm, int rTo, int cFrm, int cTo) {
		sht.addMergedRegion(new CellRangeAddress(rFrm,rTo,cFrm,cTo));
	}
	
	public void toSetLink(String URL) {
		link.setAddress(URL);
		cell.setHyperlink(link);
	}
	
	public void fileCreation() throws IOException {
		out = new FileOutputStream(new File("D:\\arul_excel\\CricBuzz.xlsx"));
		wbk.write(out);
		out.close();
	}
}