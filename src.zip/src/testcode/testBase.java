package testcode;



import utilities.ExcelWrite;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import pageobject.FirstPage;

public class testBase {

	static WebDriver driver = null;
	static ExcelWrite ELObj = null;
	
	public void setUP(String bURL) {
		 System.setProperty("webdriver.chrome.driver","D:\\arulpython\\driver\\chromedriver.exe");
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 driver.get(bURL);
		 PageFactory.initElements(driver,FirstPage.class);
		 ELObj = new ExcelWrite();
		 new FirstPage(driver);
	}
	
	public void toCloseWD() {
		 driver.close();
	}

}
