package sourcecode;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import testcode.CurrentMatchtest;
import testcode.testBase;
import utilities.ExcelWrite;
import pageobject.FirstPage;
import pageobject.CurrentMatch;

public class Mainfile {

	static WebDriver driver = null;
	static ExcelWrite ELObj = null;
	
	
	@BeforeTest
	@Parameters({"baseURL"})
	public void beforeClass(String bURL){
		new testBase().setUP(bURL);;
	}
	
	@Test
	@Parameters({"curMatch"})
	public void CurrentMatch(String cMatch) throws IOException, InterruptedException{
		new CurrentMatchtest().curMatch(cMatch);
	}
	
	@AfterTest
	 public void afterTest() {
		 new testBase().toCloseWD();
	 }

	}